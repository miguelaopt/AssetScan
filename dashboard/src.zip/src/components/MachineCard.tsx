import React from 'react';

// Pode ser que tenhas um tipo específico para a 'Machine', 
// mas usar 'any' por agora resolve o erro para poderes ver o ecrã.
export default function MachineCard({ machine }: { machine: any }) {
    return (
        <div className="liquid-glass rounded-xl p-6 border border-white/10">
            <h3 className="text-xl font-bold text-white mb-2">
                {machine.custom_name || machine.hostname}
            </h3>
            <p className="text-gray-400 text-sm">
                IP: {machine.local_ip || 'N/A'}
            </p>
            <div className="mt-4">
                {machine.is_online ? (
                    <span className="badge-apple-online">Online</span>
                ) : (
                    <span className="badge-apple text-gray-500">Offline</span>
                )}
            </div>
        </div>
    );
}